import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import { GUI } from 'three/addons/libs/lil-gui.module.min.js';
import {OBJLoader} from 'three/addons/loaders/OBJLoader.js';
import { MTLLoader } from 'three/addons/loaders/MTLLoader.js';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { Player, PlayerController, ThirdPersonCamera } from "./player.js";
import gsap from 'gsap'; 
class MinMaxGUIHelper {
    constructor(obj, minProp, maxProp, minDif) {
      this.obj = obj;
      this.minProp = minProp;
      this.maxProp = maxProp;
      this.minDif = minDif;
    }
    get min() {
      return this.obj[this.minProp];
    }
    set min(v) {
      this.obj[this.minProp] = v;
      this.obj[this.maxProp] = Math.max(this.obj[this.maxProp], v + this.minDif);
    }
    get max() {
      return this.obj[this.maxProp];
    }
    set max(v) {
      this.obj[this.maxProp] = v;
      this.min = this.min;  // this will call the min setter
    }
  }

//Setup canvas render
const renderer = new THREE.WebGLRenderer();
renderer.setSize( window.innerWidth, window.innerHeight );
renderer.shadowMap.enabled = true; // enabling shadow map
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
document.body.appendChild( renderer.domElement );


//Setup Scene and Camera
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 1000 );
console.log(camera.zoom)

const size = 1;
// const camera = new THREE.OrthographicCamera( - size, size, size, - size, 0.1,1000 );
camera.position.set( 0, 50, 50 );
camera.zoom = 1;
camera.lookAt( 0, 0, 0 );


function updateCamera() {
    camera.updateProjectionMatrix();
}
   
const gui = new GUI();
// gui.add(camera, 'fov', 1, 180).onChange(updateCamera);
const minMaxGUIHelper = new MinMaxGUIHelper(camera, 'near', 'far', 0.1);
gui.add(minMaxGUIHelper, 'min', 0.1, 50, 0.1).name('near').onChange(updateCamera);
gui.add(minMaxGUIHelper, 'max', 0.1, 1000, 0.1).name('far').onChange(updateCamera);

// ORBIT CONTROL
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 8, 10);
controls.keys = {
	LEFT: 'KeyA', //left arrow
	UP: 'KeyW', // up arrow
	RIGHT: 'KeyD', // right arrow
	BOTTOM: 'KeyS' // down arrow
}
controls.update();

// var theta = 0;
// var phi = Math.PI/2;

// function updateOrbitControls() {
//   const radius = 230; // Distance from the target
//   camera.position.x = radius * Math.sin(phi) * Math.cos(theta);
//   camera.position.y = radius * Math.cos(phi);
//   camera.position.z = radius * Math.sin(phi) * Math.sin(theta);
//   camera.lookAt(controls.target);
//   controls.update();
// }


// Background
{
  const texture = new THREE.TextureLoader().load('resources/enviroment/panoramic-view-sunset-night123.jpg' ); 
  scene.background = texture;
}



const planeSizeWidth = 400;
const planeSizeLength = 400;
var planeGeo = new THREE.PlaneGeometry(planeSizeWidth, planeSizeLength);
var planeMat = new THREE.MeshPhongMaterial({
    color: '#05a3b5',
    side: THREE.DoubleSide,
});

var mesh = new THREE.Mesh(planeGeo, planeMat);
mesh.receiveShadow = true
mesh.rotation.x = Math.PI * -.5;
scene.add(mesh);

{
  const texture = new THREE.TextureLoader().load('resources/enviroment/panoramic-view-sunset-night123.jpg' ); 
  scene.background = texture; 
}

//// ---------------- OBJECT ----------------
// MOON
var moonGeometry = new THREE.SphereGeometry(7, 32, 16);
var moonMaterial = new THREE.MeshBasicMaterial({color: '#F6F1D5'});
var moon = new THREE.Mesh(moonGeometry, moonMaterial);
moon.castShadow = true;
scene.add(moon);
// moon.position.set(115,200,-110)
moon.position.set(60, 130, -70)

// Lantern 1 (dekat sign & jembatan)
var lanternLight1Geometry = new THREE.SphereGeometry(0.3, 32, 16 ); 
var lanternLight1Material = new THREE.MeshBasicMaterial( { color: '#FDB813' } ); 
var lanternLight1 = new THREE.Mesh( lanternLight1Geometry, lanternLight1Material ); 
lanternLight1.position.set(3.27, 12.3, 18.9)
lanternLight1.receiveShadow = true;
lanternLight1.castShadow = true;
scene.add(lanternLight1);

// Lantern 2 (dekat jembatan)
var lanternLight2Geometry = new THREE.SphereGeometry(0.3, 32, 16 ); 
var lanternLight2Material = new THREE.MeshBasicMaterial( { color: '#FDB813' } ); 
var lanternLight2 = new THREE.Mesh( lanternLight2Geometry, lanternLight2Material ); 
lanternLight2.position.set(-0.5, 12.3, 7);
lanternLight2.receiveShadow = true;
lanternLight2.castShadow = true;
scene.add(lanternLight2);

// Lantern 3 (dekat gua)
var lanternLight3Geometry = new THREE.SphereGeometry(0.3, 32, 16 ); 
var lanternLight3Material = new THREE.MeshBasicMaterial( { color: '#FDB813' } ); 
var lanternLight3 = new THREE.Mesh( lanternLight3Geometry, lanternLight3Material ); 
lanternLight3.position.set(-16.5, 12.3, 7.37);
lanternLight3.castShadow = true;
lanternLight3.receiveShadow = true;
scene.add(lanternLight3);

// Lantern 4 (dekat tangga)
var lanternLight4Geometry = new THREE.SphereGeometry(0.3, 32, 16 ); 
var lanternLight4Material = new THREE.MeshBasicMaterial( { color: '#FDB813' } ); 
var lanternLight4 = new THREE.Mesh( lanternLight4Geometry, lanternLight4Material ); 
lanternLight4.position.set(-14.18, 27.3, -17.36);
lanternLight4.receiveShadow = true;
lanternLight4.castShadow = true;
scene.add(lanternLight4);

// Lantern 5 (dekat pagar)
var lanternLight5Geometry = new THREE.SphereGeometry(0.3, 32, 16 ); 
var lanternLight5Material = new THREE.MeshBasicMaterial( { color: '#FDB813' } ); 
var lanternLight5 = new THREE.Mesh( lanternLight5Geometry, lanternLight5Material ); 
lanternLight5.position.set(-1.82, 27.3, -11.46);
lanternLight5.receiveShadow = true;
lanternLight5.castShadow = true;
scene.add(lanternLight5);

// Lantern 6 (dekat air terjun)
var lanternLight6Geometry = new THREE.SphereGeometry(0.3, 32, 16 ); 
var lanternLight6Material = new THREE.MeshBasicMaterial( { color: '#FDB813' } ); 
var lanternLight6 = new THREE.Mesh( lanternLight6Geometry, lanternLight6Material ); 
lanternLight6.position.set(10, 27.3, -13.46);
lanternLight6.receiveShadow = true;
lanternLight6.castShadow = true;
scene.add(lanternLight6);


// Light House Light (tabung cahaya utama)
var lightHouseCylinderGeometry = new THREE.CylinderGeometry( 2, 2, 3, 32 ); 
var lightHouseCylinderMaterial = new THREE.MeshBasicMaterial( {color: 0xffff00} ); 
var lightHouseCylinder = new THREE.Mesh( lightHouseCylinderGeometry, lightHouseCylinderMaterial ); 
lightHouseCylinder.position.set(110.7,23.8,123.97);
scene.add( lightHouseCylinder );

// Text for Transparent sign
const signCanvas = document.createElement('canvas');
const signContext = signCanvas.getContext('2d');
signCanvas.width = 512;
signCanvas.height = 512;

//background
signContext.fillStyle = 'rgba(255, 255, 255, 0)'; // Transparent background
signContext.fillRect(0, 0, signCanvas.width, signCanvas.height);

// Draw text
signContext.fillStyle = 'white';
signContext.font = '44px Arial';

const text = 'DILARANG BERENANG';
const textMetrics = signContext.measureText(text);
const textWidth = textMetrics.width;
const textHeight = 44; // This should match the font size
const x = (signCanvas.width - textWidth) / 2;
const y = (signCanvas.height + textHeight) / 2;
signContext.fillText(text, x, y);
const textTexture = new THREE.CanvasTexture(signCanvas);

// Transparent Sign (sign)
// glass
const glassTransparencyMaterial = new THREE.MeshPhongMaterial({
  color: '#A7C7CB',
  transparent: true,
  opacity: 0.6,
  shininess: 100,
  refractionRatio: 0.98,
  reflectivity: 0.9
});

const signGlassGeometry = new THREE.BoxGeometry(6, 3, 0.7);
const signGlassMaterial = [
  glassTransparencyMaterial, // kanan
  glassTransparencyMaterial, // kiri
  glassTransparencyMaterial, // atas
  glassTransparencyMaterial, // bawah
  new THREE.MeshPhongMaterial({ map: textTexture, transparent: true, opacity: 4}), // depan
  glassTransparencyMaterial, // belakang
]
const signGlass = new THREE.Mesh(signGlassGeometry, signGlassMaterial);
scene.add(signGlass);
signGlass.position.set (-25, 5, 50);
signGlass.castShadow = true;
signGlass.receiveShadow = true;


// wood
const textureLoader = new THREE.TextureLoader();
const woodTexture = textureLoader.load('resources/enviroment/wood_texture.jpg');
const signWoodGeometry = new THREE.BoxGeometry(0.5, 5, 0.5);
const signWoodMaterial = new THREE.MeshPhongMaterial({ map: woodTexture});
const signWood = new THREE.Mesh(signWoodGeometry, signWoodMaterial);
scene.add(signWood);
signWood.position.set (-25, 2, 50);
signWood.castShadow = true;
signWood.receiveShadow = true;





////---------------- LIGHTING ----------------
// Ambient light
const ambientLight = new THREE.AmbientLight('#F6F1D5', 0.2);
scene.add(ambientLight);

// DIRECTIONAL LIGHT 

//(Cahaya Bulan)
var moonDirectionalLight = new THREE.DirectionalLight('#F6F1D5', 0.25);
moonDirectionalLight.position.set(60, 130, -70);
moonDirectionalLight.target.position.set(0,0,0);
scene.add(moonDirectionalLight);
scene.add(moonDirectionalLight.target);
// Helper Cahaya bulan
var moonDirectionalLightHelper = new THREE.DirectionalLightHelper(moonDirectionalLight);
scene.add(moonDirectionalLightHelper);
moonDirectionalLight.castShadow = true;


//Additional Light
var additionalDirectionalLight = new THREE.DirectionalLight('#FDB813', 0.006);
additionalDirectionalLight.position.set(-120, 15, 135);
additionalDirectionalLight.target.position.set(0,20,0);
scene.add(additionalDirectionalLight);
scene.add(additionalDirectionalLight.target);
// // HELPER
var additionalDirectionalLightHelper = new THREE.DirectionalLightHelper(additionalDirectionalLight);
scene.add(additionalDirectionalLightHelper);

// POINT LIGHT

// Campfire 1 (dekat kemah)
const campfire1PointLight = new THREE.PointLight( '#aa4203', 55, 250 );
campfire1PointLight.decay = 1.5;
campfire1PointLight.position.set( -10.3, 11.4, 26.3 );
campfire1PointLight.castShadow = true;
scene.add( campfire1PointLight );
// HELPER
const sphereSize = 10;
const campfire1PointLightHelper = new THREE.PointLightHelper( campfire1PointLight, sphereSize );
scene.add( campfire1PointLightHelper );

// Campfire 2 (dekat rumah)
const campfire2PointLight = new THREE.PointLight( '#aa4203', 55, 250 );
campfire2PointLight.decay = 1.5;
campfire2PointLight.position.set(-44.7, 11.5, -55.8);
campfire2PointLight.castShadow = true;
scene.add( campfire2PointLight );



// Cahaya Lantern 1 (dekat sign)
const lantern1PointLight = new THREE.PointLight('#fcd574', 15, 100);
lantern1PointLight.position.set(3.27, 12.3, 18.9);
lantern1PointLight.castShadow = true;
scene.add(lantern1PointLight);

// Cahaya Lantern 2 (dekat jembatan)
const lantern2PointLight = new THREE.PointLight('#fcd574', 15, 100);
lantern2PointLight.position.set(-0.5, 12.3, 7);
lantern2PointLight.castShadow = true;
scene.add(lantern2PointLight);

// Cahaya Lantern 3 (dekat Gua)
const lantern3PointLight = new THREE.PointLight('#fcd574', 13, 100);
lantern3PointLight.position.set(-16.5, 12.3, 7.37);
lantern3PointLight.castShadow = true;
scene.add(lantern3PointLight);

// Cahaya Lantern 4 (dekat tangga)
const lantern4PointLight = new THREE.PointLight('#fcd574', 15, 100);
lantern4PointLight.position.set(-14.18, 27.3, -17.36);
lantern4PointLight.castShadow = true;
scene.add(lantern4PointLight);

// Cahaya lantern 5 (dekat pager)
const lantern5PointLight = new THREE.PointLight('#fcd574', 15, 100);
lantern5PointLight.position.set(-1.82, 27.3, -11.46);
lantern5PointLight.castShadow = true;
scene.add(lantern5PointLight);

// Cahaya Lantern 6 (dekat air terjun)
const lantern6PointLight = new THREE.PointLight('#fcd574', 15, 100);
lantern6PointLight.position.set(10, 27.3, -13.46);
lantern6PointLight.castShadow = true;
scene.add(lantern6PointLight);

// SPOTLIGHT
// Cahaya Lighthouse
const lighthouseRadius = 5;
const lightHouseSpotLight = new THREE.SpotLight('#CEC7B8', 500);
lightHouseSpotLight.position.set(110.7, 23.8, 123.97);
lightHouseSpotLight.penumbra = 0.7;
lightHouseSpotLight.focus = 1;
lightHouseSpotLight.decay = 1.3;
lightHouseSpotLight.angle = 0.120427718387609;
lightHouseSpotLight.castShadow = true;
lightHouseSpotLight.shadow.mapSize.width = 2048;
lightHouseSpotLight.shadow.mapSize.height = 2048;

scene.add(lightHouseSpotLight);

const LHSPTargetPivot = new THREE.Object3D();
scene.add(LHSPTargetPivot);
LHSPTargetPivot.position.set(110.7, 23.8, 123.97);

const LHSPTargetPosition = new THREE.Vector3(120.7, 23.8, 103.97);
lightHouseSpotLight.target = LHSPTargetPivot;

var SpotLightHelper = new THREE.SpotLightHelper(lightHouseSpotLight);
scene.add(SpotLightHelper);



// {
//   // model
//   const box = new THREE.Box3();
//   const scale = 7;
//   const loader = new GLTFLoader().setPath( 'resources/asset nature/GLTF format/' );
//   loader.load( 'tent_detailedOpen.glb', function ( gltf ) {

//     const model = gltf.scene;
//     model.castShadow = true;
//     renderer.compileAsync( model, camera, scene );
//     model.scale.set(scale ,scale,scale)
//     model.rotation.y = 4.15
//     model.position.y = -0.03
//     model.position.set(-17,9.8,20);
//     scene.add( model );
//     box.setFromObject(model)
//     box.setFromCenterAndSize( new THREE.Vector3( 1, 1, 1 ), new THREE.Vector3( 2, 1, 3 ) );
    
//     const helper = new THREE.Box3Helper( box, 0xffff00 );
//     scene.add( helper );


//   } );

// }








// function jalan(dt){
//   this.animasiChar.position.x += 1;
// }


{

  // bounding box tenda
  
  const geometry = new THREE.BoxGeometry( 7, 15, 6 ); 
  const material = new THREE.MeshBasicMaterial( {color: 0x00ff00 , opacity:0, transparent:true} ); 
  const cube = new THREE.Mesh( geometry, material ); 
  cube.position.set(-18,6.8,20.8);
  cube.rotation.y = 4.4;
 
  
  cube.geometry.computeBoundingBox();

  const box = new THREE.Box3();
  box.setFromObject(cube)
  console.log(box)
  const helper = new THREE.Box3Helper( box, 0xffffff ); 
  scene.add( helper );
  scene.add(cube)
} 

{

  // bounding box crops jagung dan sayur
  
  const geometry = new THREE.BoxGeometry( 15.7, 18, 6 ); 
  const material = new THREE.MeshBasicMaterial( {color: 0x00ff00 , opacity:0, transparent:true} ); 
  const cube = new THREE.Mesh( geometry, material ); 
  cube.position.set(1.9,7.8,31.9);
 
  
  cube.geometry.computeBoundingBox();

  const box = new THREE.Box3();
  box.setFromObject(cube)
  console.log(box)
  const helper = new THREE.Box3Helper( box, 0xffffff ); 
  scene.add( helper );
  scene.add(cube)
} 

{

  // bounding box pohon 1
 
  var radius = 1;
  const geometry = new THREE.CylinderGeometry( radius, radius, 18, 32 ); 
  const material = new THREE.MeshBasicMaterial( {color: 0xffff00, opacity:0, transparent:true} ); 
  const cylinder = new THREE.Mesh( geometry, material ); scene.add( cylinder );
  cylinder.position.set(-33.6,7.8,19.2);

  scene.add(cylinder)
  
  cylinder.geometry.computeBoundingBox();

  const boxPohon = new THREE.Box3();
  boxPohon.setFromObject(cylinder)
  console.log(boxPohon)
  const helper = new THREE.Box3Helper( boxPohon, 0xffffff ); 
  scene.add( helper );
}

{

  // bounding box pohon 2
  
  var radius = 0.6;
  const geometry = new THREE.CylinderGeometry( radius, radius, 18, 32 ); 
  const material = new THREE.MeshBasicMaterial( {color: 0xffff00, opacity:0, transparent:true} ); 
  const char = new THREE.Mesh( geometry, material );
   scene.add( char );
  char.position.set(-6.2,7.8,15.9);
    
  char.geometry.computeBoundingBox();

  const boxChar = new THREE.Box3();
  boxChar.setFromObject(char)
  console.log(boxChar)
  const helper = new THREE.Box3Helper( boxChar, 0xffffff ); 
  scene.add( helper );
}






{
  // model

  const loader = new GLTFLoader().setPath( 'resources/enviroment/' );
  loader.load( 'dunia.gltf', function ( gltf ) {

    const model = gltf.scene;
    model.traverse(function(node){
      if (node.isMesh){
              node.castShadow = true;
              node.receiveShadow = true;
      }

    });
    renderer.compileAsync( model, camera, scene );
    model.scale.set(5,5,5)
    model.rotation.y = 3.15
    model.position.y = -0.03
    scene.add( model );



  } );
}




var mixer1;
var mixer;

{
  const texture = new THREE.TextureLoader().load('resources/Character/wizzard/texture/StandardBaseColorTex.png' ); 
  // model
  const loader = new FBXLoader();
  loader.load( 'resources/Character/wizzard/char/IdleWizzard.FBX', function ( object ) {

    console.log(object);
    mixer1 = new THREE.AnimationMixer( object );

    const action = mixer1.clipAction( object.animations[ 0 ] );
    action.play();
    object.scale.setScalar(0.02);
    object.position.set(-30,9.7,9);
    object.rotation.z = Math.PI * .010;
    object.rotation.x = Math.PI * -.5;
   

    object.traverse( function ( child ) {

      if ( child.isMesh ) {

        child.castShadow = true;
        child.receiveShadow = true;
        child.material.map = texture;
      }

    } );

    scene.add( object );
 
  } );


}

{
  const texture = new THREE.TextureLoader().load('resources/Character/wizzard/texture/MaskTintTex.PNG' ); 
  // model
  const loader = new FBXLoader();
  loader.load( 'resources/Character/wizzard/char/WalkForwardAnim.FBX', function ( object ) {

    console.log(object);
    mixer = new THREE.AnimationMixer( object );

    const action = mixer.clipAction( object.animations[ 0 ] );
    action.play();
    object.scale.setScalar(0.02);
    object.position.set(-20,9.5,11);
    object.rotation.z = Math.PI * +.5;
    object.rotation.x = Math.PI * -.5;
    mesh = object;

    object.traverse( function ( child ) {

      if ( child.isMesh ) {

        child.castShadow = true;
        child.receiveShadow = true;
        child.material.map = texture;
      }

    } );

    scene.add( object );
 
  } );


}

{
  // // ThirdPersonCamera
  //       var player = new Player(
  //           new ThirdPersonCamera(
  //               camera, new THREE.Vector3(-6,7,2), new THREE.Vector3(0,0,0)
  //           ),
  //           new PlayerController(),
  //           scene,
  //           10
  //       );

}


  const onProgress = function ( xhr ) {

    if ( xhr.lengthComputable ) {

      const percentComplete = xhr.loaded / xhr.total * 100;
      console.log( percentComplete.toFixed( 2 ) + '% downloaded' );

    }

  };
  var keys = {};

  var handleKeyDown = function (e) {
      keys[e.key] = true;
  };

  var handleKeyUp = function (e) {
      keys[e.key] = false;
  };

var handleKeys = function () {
      //CONTROL
      if (keys["q"]) {
          camera.zoom += 0.05;
      }      
      if (keys["e"]) {
          camera.zoom += 0.05;
      }
      camera.updateProjectionMatrix()
  };

  var belok = false
  var balik1 = false
  var balik2 = false
  var xChar = 0;
  var zChar = 0;
  const clock = new THREE.Clock();
  var time_prev = 0
function animate(time) {
	var dt = time - time_prev
  dt*=0.1;

  if(!belok){
        if(xChar < 0.97){
          mesh.position.x += 0.02;
          xChar += 0.001;
          // console.log(xChar)
      }else{
        belok = true;
        mesh.rotation.z = Math.PI * -.010;
      }
  } else if (belok) {
      if(!balik1){
        if(zChar <= 0.50){
          // console.log("z = " , zChar)
          zChar += 0.001; 
          mesh.position.z += 0.02;
        }else{
          balik1 = true;
          mesh.rotation.z = Math.PI ;
        }
      
      } 
  } if (balik1){
    if(zChar >= 0){
      // console.log("z = " , zChar)
      zChar -= 0.001; 
      mesh.position.z -= 0.02;
    } else {
      mesh.rotation.z = Math.PI * -.5;
      balik2 = true;
    }

    if (balik2){
      if(xChar >= 0){
        xChar -= 0.001;
        // console.log(xChar)
        mesh.position.x -= 0.02;
      } else {
        mesh.rotation.z = Math.PI * +.5;
        belok = false
        balik1 = false
        balik2 = false
      }
    }
  }


  // Rotate the spotlight around the lighthouse
  const angle = -0.005 * dt; // Adjust rotation speed as needed
  const offsetX = lightHouseSpotLight.position.x - LHSPTargetPivot.position.x;
  const offsetZ = lightHouseSpotLight.position.z - LHSPTargetPivot.position.z;
  lightHouseSpotLight.position.x = LHSPTargetPivot.position.x + offsetX * Math.cos(angle) - offsetZ * Math.sin(angle);
  lightHouseSpotLight.position.z = LHSPTargetPivot.position.z + offsetX * Math.sin(angle) + offsetZ * Math.cos(angle);
  lightHouseSpotLight.position.y = 23.8; // Ensure the spotlight stays at the same height
  
  //rotate spot light on light house
  // LHSPTargetPosition.applyAxisAngle(new THREE.Vector3(0, 1, 0), 0.05); // Adjust the rotation speed as needed
  LHSPTargetPivot.position.copy(LHSPTargetPosition);
  lightHouseSpotLight.target.updateMatrixWorld();

  
  
  
  
  // mesh.position.x += 1;
  handleKeys();
  
  const delta = clock.getDelta();
  // player.update(delta); 
  if ( mixer ) mixer.update( delta );
  if ( mixer1 ) mixer1.update( delta );
  
  
  SpotLightHelper.update(); 
  renderer.render( scene, camera );

    time_prev = time;
    requestAnimationFrame( animate );
    
}
requestAnimationFrame( animate );

// Orbit Control Animation
function animateOrbit(time) {
  theta += 0.01; // Adjust this value to change the rotation speed
  updateOrbitControls();
  requestAnimationFrame(animateOrbit);
  renderer.render(scene, camera);
}

animateOrbit();